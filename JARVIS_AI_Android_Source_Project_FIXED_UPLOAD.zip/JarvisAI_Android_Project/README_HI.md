# JARVIS AI – Android starter project

यह Android ऐप का शुरुआती source project है। इसमें:
- Hindi speech recognition (फोन की Speech Recognition सेवा पर निर्भर)
- Hindi Text-to-Speech
- Gemini chat integration
- स्थानीय फोन में Gemini API key सेव करना
- Dark JARVIS-style chat UI

## जरूरी बातें
1. यह अभी source project है, तैयार APK नहीं।
2. APK बनाने के लिए Android Studio वाला कंप्यूटर/क्लाउड Android build environment चाहिए।
3. Gemini API key Google AI Studio से लें: https://aistudio.google.com/app/apikey
4. API key निजी रखें। इसे चैट, स्क्रीनशॉट या सार्वजनिक जगह पर साझा न करें।
5. Gemini API की उपलब्धता, मॉडल और free-tier limits समय/देश/खाते के अनुसार बदल सकती हैं।
6. ऐप में API key फोन के private SharedPreferences में रखी जाती है, लेकिन यह production-grade secure backend का विकल्प नहीं है। सार्वजनिक रूप से ऐप बाँटने से पहले backend/proxy और Firebase App Check जैसे सुरक्षा उपाय जोड़ें।

## Build
- Android Studio में इस folder को Open करें।
- Gradle sync पूरा करें।
- Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
- फोन में APK इंस्टॉल करते समय Android की install permission दें।

## Package
`com.jarvis.assistant`

## अभी शामिल नहीं
WhatsApp auto-send, background always-listening wake word, full phone control, cloud sync, reminders scheduling और image/video generation. इन्हें अलग-अलग permissions, integrations और सुरक्षा जाँच के साथ अगले versions में जोड़ना होगा।
