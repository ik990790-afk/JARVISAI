package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Night = Color(0xFF070B16)
private val Panel = Color(0xFF111B30)
private val Cyan = Color(0xFF38D9FF)
private val Muted = Color(0xFF9BAAC4)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisApp(onSpeak = { speak(it) }) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale("en", "IN")
            }
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis_settings", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("नमस्ते! मैं JARVIS हूँ। आप मुझसे हिंदी में बात कर सकते हैं। Gemini AI चालू करने के लिए Settings में API key जोड़ें।", false)
        )
    }
    val scope = rememberCoroutineScope()

    val speechPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startHindiRecognition(context) { result ->
            input = result
            listening = false
        } else {
            messages.add(ChatMessage("माइक्रोफोन की अनुमति नहीं मिली। आप लिखकर बात कर सकते हैं।", false))
            listening = false
        }
    }

    fun sendMessage(raw: String) {
        val question = raw.trim()
        if (question.isEmpty() || busy) return
        messages.add(ChatMessage(question, true))
        input = ""
        busy = true
        scope.launch {
            val answer = withContext(Dispatchers.IO) {
                if (apiKey.isBlank()) {
                    "अभी Gemini कनेक्ट नहीं है। ऊपर Settings खोलकर अपनी Gemini API key जोड़ें। तब मैं AI से जवाब दे पाऊँगा।"
                } else {
                    runCatching { askGemini(apiKey, question) }
                        .getOrElse { "माफ़ कीजिए, अभी जवाब नहीं मिल पाया। इंटरनेट और API key जाँचें। विवरण: ${it.message ?: "Unknown error"}" }
                }
            }
            messages.add(ChatMessage(answer, false))
            busy = false
            onSpeak(answer)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Night, surface = Panel, primary = Cyan,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Night,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("JARVIS AI", color = Color.White, fontSize = 20.sp)
                            Text("आपका हिंदी पर्सनल असिस्टेंट", color = Muted, fontSize = 11.sp)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, "Settings", tint = Cyan)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Night)
                )
            },
            bottomBar = {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Panel).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                                == PackageManager.PERMISSION_GRANTED) {
                                listening = true
                                startHindiRecognition(context) { result ->
                                    input = result
                                    listening = false
                                }
                            } else {
                                listening = true
                                speechPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    ) {
                        Icon(Icons.Default.Mic, "बोलें", tint = if (listening) Color.Green else Cyan)
                    }
                    Box(
                        Modifier.weight(1f).background(Night, RoundedCornerShape(24.dp)).padding(13.dp)
                    ) {
                        if (input.isEmpty()) Text("यहाँ लिखें या माइक दबाएँ…", color = Muted)
                        BasicTextField(
                            value = input, onValueChange = { input = it },
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    IconButton(onClick = { sendMessage(input) }, enabled = !busy) {
                        Icon(Icons.Default.Send, "Send", tint = Cyan)
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)
                        .background(Brush.verticalGradient(listOf(Color(0xFF102D4B), Color(0xFF0A1224))), RoundedCornerShape(22.dp))
                        .padding(18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(86.dp).background(
                                Brush.radialGradient(listOf(Color(0xFF1A789D), Color(0xFF10223D), Night)),
                                CircleShape
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("J", color = Cyan, fontSize = 42.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(if (busy) "सोच रहा हूँ…" else if (listening) "सुन रहा हूँ…" else "मैं तैयार हूँ", color = Cyan)
                        Text("VOICE • AI • ASSISTANT", color = Muted, fontSize = 10.sp)
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(messages) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Text(
                                msg.text,
                                modifier = Modifier.widthIn(max = 310.dp)
                                    .background(if (msg.fromUser) Color(0xFF123B58) else Panel, RoundedCornerShape(16.dp))
                                    .padding(13.dp),
                                color = Color.White, fontSize = 14.sp
                            )
                        }
                    }
                    if (busy) item { Text("JARVIS जवाब तैयार कर रहा है…", color = Cyan, modifier = Modifier.padding(8.dp)) }
                }
                Text(
                    "नोट: संदेश भेजने से पहले जाँच लें। API key आपके फोन में स्थानीय रूप से सेव होती है।",
                    color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(10.dp)
                )
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Gemini AI सेटअप") },
                text = {
                    Column {
                        Text("Google AI Studio से अपनी Gemini API key बनाएँ और यहाँ पेस्ट करें। इसे किसी के साथ साझा न करें।", fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = apiKey, onValueChange = { apiKey = it },
                            label = { Text("Gemini API key") },
                            singleLine = true
                        )
                        TextButton(onClick = { apiKey = ""; prefs.edit().remove("gemini_key").apply() }) {
                            Text("Key हटाएँ")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        prefs.edit().putString("gemini_key", apiKey.trim()).apply()
                        showSettings = false
                    }) { Text("सेव करें") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("बंद करें") } }
            )
        }
    }
}

private fun startHindiRecognition(
    context: android.content.Context,
    onResult: (String) -> Unit
) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
        onResult("इस डिवाइस पर Speech Recognition उपलब्ध नहीं है।")
        return
    }
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS से बात करें")
    }
    recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { recognizer.destroy() }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) onResult(text)
            recognizer.destroy()
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    recognizer.startListening(intent)
}

private fun askGemini(apiKey: String, prompt: String): String {
    val client = OkHttpClient()
    val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey"
    val system = "तुम JARVIS नाम के सहायक हो। हमेशा सरल, स्पष्ट हिंदी में जवाब दो। उपयोगकर्ता के फोन पर कोई कार्रवाई करने का दावा मत करो जब तक वास्तव में वह कार्रवाई उपलब्ध और अधिकृत न हो।"
    val parts = JSONArray().put(JSONObject().put("text", "$system\n\nउपयोगकर्ता: $prompt"))
    val body = JSONObject().put(
        "contents", JSONArray().put(JSONObject().put("parts", parts))
    ).toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    val request = Request.Builder().url(url).post(body).build()
    client.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("Gemini API ${response.code}: $raw")
        val json = JSONObject(raw)
        return json.getJSONArray("candidates")
            .getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getString("text")
    }
}
