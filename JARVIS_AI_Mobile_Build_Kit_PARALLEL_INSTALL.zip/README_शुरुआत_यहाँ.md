JARVIS AI - Updated Android Build Kit

This kit builds a separate JARVIS AI app with application ID:
com.jarvis.assistant.v2

It is intentionally separate from the earlier installed app so the old app and its locally stored Gemini API key remain untouched.

Upload this ZIP to the root of your GitHub repository using the same filename:
JARVIS_AI_Mobile_Build_Kit_NEW.zip

Then GitHub Actions should build a new APK artifact named JARVIS-AI-APK.
Install the new app alongside the old one. Do not uninstall the old app unless you have safely saved your API key.

Keep your Gemini API key private. It is not included in this ZIP.
