# JARVIS AI — मोबाइल से APK बनाने का किट

यह किट आपके Android फोन से GitHub के जरिए Android ऐप का APK बनाने के लिए है।

## इसमें क्या है
- `JARVIS_AI_Android_Source_Project.zip` — Android ऐप का Kotlin source project
- `.github/workflows/build-apk.yml` — GitHub Actions पर APK बनाने का workflow

## मोबाइल से इस्तेमाल करने के चरण

1. Chrome में https://github.com/signup खोलकर मुफ्त GitHub अकाउंट बनाएं।
2. नया repository बनाएं। नाम रखें `jarvis-ai` और Public चुनें (GitHub Free पर public repo में Actions minutes की सीमा कम बाधक होती है; निजी डेटा या API keys repo में न डालें)।
3. Repository में **Add file → Upload files** चुनें।
4. `JARVIS_AI_Android_Source_Project.zip` अपलोड करें।
5. `.github/workflows/build-apk.yml` बनाने के लिए **Add file → Create new file** चुनें। Filename बिल्कुल यही रखें: `.github/workflows/build-apk.yml`; इस किट की workflow फाइल का पूरा content कॉपी करके पेस्ट करें।
6. Commit changes करें।
7. Repository के **Actions** tab में `Build JARVIS AI APK` workflow खोलें। जरूरत हो तो **Run workflow** दबाएं।
8. Build सफल होने पर run खोलें, नीचे **Artifacts** में `JARVIS-AI-debug-APK` डाउनलोड करें।
9. ZIP artifact खोलें; उसमें `app-debug.apk` मिलेगा। उसे फोन में इंस्टॉल करें। Android पूछे तो Chrome/Files के लिए install permission दें।

## सुरक्षा और वास्तविक सीमाएँ
- यह शुरुआती prototype है, अंतिम production app नहीं।
- Gemini API key अपने फोन में ऐप की Settings में डालें; उसे GitHub repository, screenshot या किसी व्यक्ति के साथ साझा न करें।
- ऐप में API key स्थानीय storage में रखी जाती है। सार्वजनिक रूप से ऐप बांटने से पहले सुरक्षित backend/proxy जोड़ना चाहिए।
- Gemini की मुफ्त उपलब्धता और limits बदल सकती हैं; कोई भुगतान शुरू करने से पहले Google की billing/usage स्क्रीन जांचें।
- हिंदी speech recognition Android/Google speech service और इंटरनेट/फोन सेटिंग पर निर्भर हो सकती है।
- WhatsApp auto-send, हमेशा सुनने वाला wake word, full phone control और automatic image/video generation अभी शामिल नहीं हैं। ये अगले चरणों में अलग अनुमतियों और integrations के साथ जोड़े जाएंगे।
